# Diccionario de Datos — NHAMCS ED 2022 (CSV depurado)
- **Archivo**: `ed2022_clean_min.csv`
- **Filas**: **16025**
- **Columnas**: **771**
- **Tamaño**: 24.82 MB
- **Memoria (pandas)**: **114.49 MB**
- **SHA256**: 7d6fbba43814945bb624b00799a69caddd4d015979942b37165d0c7d9ea9fffc

**Vista completa (CSV)**: `DATADICT_full.csv`
**Partes Markdown** (4 archivos):
- `DATADICT_part1.md`
- `DATADICT_part2.md`
- `DATADICT_part3.md`
- `DATADICT_part4.md`